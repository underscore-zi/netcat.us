#include <iostream>
#include <string.h>
#include "AES256.hpp"
#include "base64.h"

int main(int argc, char **argv)
{
    std::string Key = base64_decode("fByD0hwt0lltW1itfK5iEuejV5GUegpoo/RcIeyOvvM=");
    
    // Key: fByD0hwt0lltW1itfK5iEuejV5GUegpoo/RcIeyOvvM=
    // Plaintext: The password is UCOABHBjCzDvzewPFQr2BVqI0ZD4e8mv
    // Encrypted: SNXIDUFQW0Ul6GXI4NyU/LMHl+vRlVIYp4pvFstfpP1n1C9Xhbl/bNip6mK5l7TMPS+vw247XTYK3LKIGT4AZVh6zUB97fN3fOamkLvzpmA=
    
    std::string input;
    std::getline(std::cin, input); // Read input from stdin
    
    std::string decrypted = AES256_Decrypt(base64_decode(input), Key); // Decrypt input
    if(decrypted == "Invalid data") // Check if the input is decrypted succesfully
        std::cout << "Failed to decrypt the message" << std::endl;
    else
        std::cout << "Successfully received and decrypted the message" << std::endl;

    return 0;
}
