#include <string>

std::string base64_encode(std::string const& data);
std::string base64_decode(std::string const& s);
