#!/bin/bash
g++ AES256.cpp base64.cpp main.cpp SHA256.cpp -o main
